package com.healthapi.health.service;

import com.healthapi.health.model.UserModel;

public interface UserService {
	UserModel addUser(UserModel user);
}